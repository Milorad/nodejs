-- 
-- CREATE TABLE USERS
-- 

CREATE TABLE t_users (
	username VARCHAR(128) PRIMARY KEY NOT NULL,
	password VARCHAR(512) NOT NULL,
	firstname VARCHAR(128),
	lastname VARCHAR(128),
	email VARCHAR(128),
	foto INTEGER REFERENCES t_pictures(id), 
	active BOOLEAN

);

