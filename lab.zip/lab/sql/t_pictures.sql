-- 
-- CREATE TABLE PICTURES
-- 

CREATE TABLE t_pictures (
	id SERIAL PRIMARY KEY NOT NULL,
	picdata BYTEA,
	description VARCHAR(200)
);
