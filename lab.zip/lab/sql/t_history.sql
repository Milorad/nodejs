-- 
-- CREATE TABLE HISTORY
-- 

CREATE TABLE t_history (
	id SERIAL PRIMARY KEY NOT NULL,
	sampleid INT REFERENCES t_sample(id),
	username VARCHAR(128) REFERENCES t_users(username),
	comment VARCHAR(256)
);
