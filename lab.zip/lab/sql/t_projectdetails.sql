-- 
-- CREATE TABLE PROJECTSdetails
-- 

CREATE TABLE t_projectdetails (
	id SERIAL PRIMARY KEY NOT NULL,
	projectid VARCHAR(64) REFERENCES t_projects(projectname),
	assistent VARCHAR(128) REFERENCES t_users(username),
	function VARCHAR(32)
);
