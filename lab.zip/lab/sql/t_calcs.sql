-- 
-- CREATE TABLE CALCS
-- 

CREATE TABLE t_calcs (
	id SERIAL PRIMARY KEY NOT NULL,
	sampleid INT REFERENCES t_sample(id),
	referencesampleid INT REFERENCES t_sample(id),
	overlap INT,
	sampleStartRing INT,
	sampleEndRing INT,
	referenceSampleStartRing INT,
	referenceSampleEndRing INT,
	glk DECIMAL(9,9),
	ttest DECIMAL(9,9),
	significance DECIMAL(9,9),
	corr_pearson DECIMAL(9,9),
	corr_spearman DECIMAL(9,9),
	corr_kendal DECIMAL(9,9),
	corr_tau DECIMAL(9,9),
	first_detrending INT REFERENCES t_calcoptions(id),
	second_detrending INT REFERENCES t_calcoptions(id),
	datatransformation INT REFERENCES t_calcoptions(id)
);

