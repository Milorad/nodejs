-- 
-- CREATE TABLE PROJECTS
-- 

CREATE TABLE t_projects (
	projectname VARCHAR(128) PRIMARY KEY NOT NULL,
	description VARCHAR(128),
	startdate DATE,
	enddate DATE,
	customerinformation VARCHAR(128)
);
