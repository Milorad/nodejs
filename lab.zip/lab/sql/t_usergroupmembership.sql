-- 
-- CREATE TABLE USERGROUPMEMBERSHIP
-- 

CREATE TABLE t_usergroupmembership (
	id SERIAL PRIMARY KEY NOT NULL,
	usernameid VARCHAR(128) REFERENCES t_users(username),
	groupnameid VARCHAR(128) REFERENCES t_groups(groupname)
);

