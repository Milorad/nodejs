CREATE OR REPLACE FUNCTION hash_update_tg() RETURNS trigger AS $$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' THEN
        NEW = digest('key_codes', 'sha256');
        RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER t_users_hash_update 
BEFORE INSERT OR UPDATE ON t_users 
FOR EACH ROW EXECUTE PROCEDURE hash_update_tg();
