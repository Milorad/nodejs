--
-- CREATE TABLE GPS DATA
--
drop table t_gpsdata;

CREATE TABLE t_gpsdata (
        id SERIAL NOT NULL PRIMARY KEY,
        latitude FLOAT NOT NULL,
        longitude FLOAT NOT NULL,
	username INTEGER,
	groupname VARCHAR(24) REFERENCES t_groups(groupname),
        date DATE,
        time TIME,
        street VARCHAR(100),
        city VARCHAR(100),
	state VARCHAR(100),
	county VARCHAR(100),
	country VARCHAR(100),
	plz INTEGER,
	elevation INTEGER,
	rowstatus VARCHAR(100),
	image1 BYTEA,
	image2 BYTEA,
	image3 BYTEA,
	image4 BYTEA,
	image5 BYTEA,
	image6 BYTEA,
	image7 BYTEA,
	image8 BYTEA,
	image9 BYTEA,
	image10 BYTEA,
	image11 BYTEA,
	image12 BYTEA,
	image13 BYTEA,
	image14 BYTEA,
	image15 BYTEA,
	image16 BYTEA,
	image17 BYTEA,
	image18 BYTEA,
	image19 BYTEA,
	image20 BYTEA
);

