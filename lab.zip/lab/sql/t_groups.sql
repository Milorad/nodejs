-- 
-- CREATE TABLE GROUPS
-- 

CREATE TABLE t_groups (
	groupname VARCHAR(20) PRIMARY KEY NOT NULL,
	description VARCHAR(200),
	sharedmail VARCHAR(100),
	role VARCHAR(32)
);

