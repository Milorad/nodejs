-- 
-- CREATE TABLE SAMPLE
-- 

CREATE TABLE t_sample (
	id SERIAL PRIMARY KEY NOT NULL,
	type VARCHAR(64),
	sampledata VARCHAR(8192),
	datierung DATE,
	waldkante BOOLEAN,
	mark BOOLEAN,
	splintholz BOOLEAN,
	splintholznumber INTEGER,
	kernholz BOOLEAN,
	kernholznumber INTEGER,
	reifholz BOOLEAN,
	reifholznumber INTEGER,
	rinde_bast BOOLEAN,
	rinde_borke BOOLEAN,
	gps_latitude DECIMAL(9,9),
	gps_longitude DECIMAL(9,9),
	elevation DECIMAL(9,9),
	fundort VARCHAR(128),
	messungsdate DATE,
	messungdoneby VARCHAR(128) REFERENCES t_users(username),
	analysedate DATE,
	analysedoneby VARCHAR(128) REFERENCES t_users(username),
	spezies INT REFERENCES t_spezies(id),
	datierungsguete VARCHAR(32),
	comments VARCHAR(256)
);
