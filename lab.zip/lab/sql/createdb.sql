CREATE TABLESPACE ts_dclab OWNER dclab LOCATION '/db/PGSQLDB/data01/tablespaces';
CREATE TABLESPACE is_dclab OWNER dclab LOCATION '/db/PGSQLDB/data01/indexes';
CREATE DATABASE dclab
  WITH OWNER = dclab
       ENCODING = 'UTF8'
       TABLESPACE = ts_dclab
       CONNECTION LIMIT = -1;
