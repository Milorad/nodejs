#!/app/node/bin/node
var pg = require('pg');

// read DB config
var dbhost = "192.168.1.200";
var dbport = "3000";
var dbname = "datacenter";
var dbssl = "false";
var dbuser = "dclab"
var dbpw = "3Fof3Tka*";
var dbparams;
var dbclient;
var dbcons = [];

dbparams = { host: dbhost, user: dbuser ,password: dbpw ,database: dbname ,ssl: dbssl };
dbclient = new pg.Client(dbparams);
dbclient.connect(function(err, result){
	if (err){
		//logger.error("User dclab cant login into database: " + err);
		console.log("conn error");
	}else{
		//logger.info("User Dclab logged in.");
		//insert
		//INSERT INTO t_gpstest (username,date,time,image20) values(1, '20.03.2014', '21:23','');
		console.log("conn OK");
		var query = "select * from t_gpstest;";
		dbclient.query(query, function(err, result){
			if (err){
				console.log("select error");
			}else{
				console.log("select ok"); 
				result.rows.forEach(function (row) {
					console.log(row.username);
					console.log(row.cdate);
					console.log(row.time);
				});
			}
		});
		
	}
});

console.log("end");
