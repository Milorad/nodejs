INSERT INTO t_users (
	username,
	password,
	role,
	firstname,
	lastname,
	email,
	foto,
	active
	) VALUES (
	'ivan',
	'cd0b9452fc376fc4c35a60087b366f70d883fc901524daf1f122fbd319384f6a',
	'user',
	'DCLab',
	'DCLab',
	'milorad.milutinovic.loki@gmail.com',
	'undefined',
	'true'
);
