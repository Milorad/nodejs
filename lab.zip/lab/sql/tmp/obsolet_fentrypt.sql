CREATE OR REPLACE FUNCTION tg_password() RETURNS trigger AS $$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' OR tg_op = 'SELECT' THEN
        NEW.password := digest(NEW.password, 'sha256');
        RETURN NEW;
    END IF;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER t_users_hash_update 
BEFORE INSERT OR UPDATE ON t_users 
FOR EACH ROW EXECUTE PROCEDURE tg_password();
