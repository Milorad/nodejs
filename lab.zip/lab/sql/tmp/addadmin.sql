INSERT INTO t_users (
	username,
	password,
	role,
	firstname,
	lastname,
	email,
	foto,
	active
	) VALUES (
	'loki',
	'982945308d3682d16636fd628c314e293499e99c00120acd9b693f5ab16e1648',
	'admin',
	'DCLab',
	'DCLab',
	'milorad.milutinovic.loki@gmail.com',
	'undefined',
	'true'
);
