#!/app/work/node/bin/node

var dbhandler = require('./tools/dbhandler');

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var https = require('https');
var path = require('path');
var fs = require('fs');
var WebSocketServer = require('websocket').server;
var options = {
  key: fs.readFileSync('./cert/server.key'),
  cert: fs.readFileSync('./cert/server.crt')
};
var async = require('async');
//
var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

dbhandler.init();

app.get('/', routes.index);
app.get('/users', user.list);

var server = https.createServer(options, function(request, response) {
    console.log((new Date()) + ' Received request for ' + request.url);
    request.on('data', function(data){
	//console.log(data);
    	//console.log(request.headers);
	var receivedJSONobj = JSON.parse(data)
	//console.log(receivedJSONobj.requestType);
	if (receivedJSONobj.requestType == "userCreate"){
		dbhandler.createUser(receivedJSONobj, function(createUserResponse){
    			response.write(createUserResponse);
    			response.end();
        	});
	}else if (receivedJSONobj.requestType == "listUser"){
		//console.log(data);
		dbhandler.listUser(function(listUserResponse){
			response.write(listUserResponse);
			response.end();
		}); 
	}
    });
    //response.writeHead(404);
    //response.setHeader('Connection', 'Transfer-Encoding');
    //response.setHeader('Content-Type', 'text/html; charset=utf-8');
    //response.setHeader('Transfer-Encoding', 'chunked');
});

server.listen(app.get('port'), function() {
    console.log((new Date()) + ' Server is listening on port 3000');
});

wsServer = new WebSocketServer({
    httpServer: server,
    autoAcceptConnections: false,
    //dropConnectionOnKeepaliveTimeout: false,
    //keepalive: false,
    maxReceivedMessageSize : 0x1E00000
//https://github.com/Worlize/WebSocket-Node/wiki/Documentation
});

function originIsAllowed(origin) {
  // put logic here to detect whether the specified origin is allowed.
  return true;
}

wsServer.on('request', function(request) {
    //console.log("IP: " + request.remoteAddress);
    if (!originIsAllowed(request.origin)) {
      // Make sure we only accept requests from an allowed origin
      request.reject();
      console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
      return;
    }

    var connection = request.accept('echo-protocol', request.origin);
    console.log((new Date()) + ' Connection accepted.');
    connection.on('message', function(message) {
	console.log('ON.MESSAGE::::loginrequest-----');
        if (message.type === 'utf8') {
	    console.log('UTF8I received------');
	    var objJSON = JSON.parse(message.utf8Data);
	    if (objJSON.loginrequest){
		//setTimeout((function() {
			dbhandler.login(objJSON.loginrequest.username, objJSON.loginrequest.passwd, function(jsonfile){
            			connection.sendUTF(jsonfile);
			});
			
		//}), 3000);
	    } else if (objJSON.addNewGPSData){
		dbhandler.addNewGPSData(objJSON.addNewGPSData, function(JSONsaveconfirmation){
			connection.sendUTF(JSONsaveconfirmation); 
			console.log("responded to addNewGPSData");
		});
		//console.log(objJSON.addNewUserData);
	    } else if (objJSON.GetUserData){
			dbhandler.GetUserData(objJSON.GetUserData.username, function(jsonfile){
				connection.sendUTF(jsonfile);
				console.log("you want user data!!" + objJSON.GetUserData.username);
			});
	    }else{
		console.log("cant parse: Unknown request of JSON-file");
	    }
            //console.log('Received Message: ' + message.utf8Data);
        }
        else if (message.type === 'binary') {
            console.log('Received Binary Message of ' + message.binaryData.length + ' bytes');
            connection.sendBytes(message.binaryData);
        }
    });
     connection.on('frame', function(frame){
	 console.log("IP: " + request.remoteAddress);
     });

    connection.on('close', function(reasonCode, description) {
	dbhandler.logout(connection);
        console.log((new Date()) + ' : ' + reasonCode + ' Peer ' + connection.remoteAddress + ' disconnected.');
    });
});

