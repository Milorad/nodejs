var pg = require('pg');
var conf = require('../conf/dclab.json');
var events = require('events');
var buffer = require('buffer');
var winston = require('winston');
var async = require('async');
var fs = require('fs');

// configure logger
var logger = new (winston.Logger)({
transports: [
	new (winston.transports.Console)(),
	new (winston.transports.File)({ filename: 'log/dclab.log' })
]
});


// read DB config
var dbhost = conf.databaseparams.url;
var dbport = conf.databaseparams.port;
var dbname = conf.databaseparams.dbname;
var dbssl = conf.databaseparams.ssl;
var dbparams;
var dbclient;
var dbcons = [];

exports.init = function(){
	var credfile = require('./conf.json');
	//var cred = require('../messages/login_nok.json');
	var credtmp = JSON.stringify(credfile);
	var cred = JSON.parse(credtmp);
	//read params
	var dbhost = cred.url;
	var dbname = cred.dbname;
	var dbuser = cred.username;
	var dbpw = cred.passwd;
	var dbssl = cred.ssl;
	dbparams = { host: dbhost, user: dbuser ,password: dbpw ,database: dbname ,ssl: dbssl };
	dbclient = new pg.Client(dbparams);
	dbclient.connect(function(err, result){
		if (err){
			logger.error("User dclab cant login into database: " + err);
		}else{
			logger.info("User Dclab logged in.");
		}
	});
}

exports.login = function(username, passwd, callback){
	var returnfile;
	var nok = require('../messages/login_nok.json');
	var nok_jstr = JSON.stringify(nok);
	var ok = require('../messages/login_ok.json');
	//var ok_jstr = JSON.stringify(ok);

	userExists(username, function(userexist){
		if (userexist){
			logger.info("User " + username + " exists.");
			//checkPassword(username, passwd, function(pwstat){
			compareHashPasswords(username, passwd, function(pwstat){
				if(pwstat){
					logger.info("User " + username + " logged in."); 
					getUserInfo(username, function(role, firstname, lastname, email, foto, active){
						ok.loginrequest.username = username;
						ok.loginrequest.role = role;
						ok.loginrequest.firstname = firstname;
						ok.loginrequest.lastname = lastname;
						ok.loginrequest.email = email;
						ok.loginrequest.foto = foto;
						ok.loginrequest.active = active;
						callback(JSON.stringify(ok));
					});
				}else{
					logger.info("Password of user " + username + " does not match."); 
					var nok = require('../messages/login_nok.json');
					nok.loginrequest.username = username;
					callback(JSON.stringify(nok));
				}
			});
		}else{
			logger.info("User " + username + " doesnt exist.");
			callback(nok_jstr);
		}
		 
	});
	//var sha256 = encryptPassword(passwd);

}

exports.logout = function(wsc){
        dbcons.forEach(function (conns) {
                if (conns.wsconn == wsc){
                        conns.dbconn.end();
                }
        });
}
function userExists(user, callback){
	var uexistquery = "select username from t_users where username like '" + user + "';";
	//console.log(uexistquery);
	dbclient.query(uexistquery, function(err, result){
		//if result 1 row, user exists
		if (err){
			//error query
		}else{
			var exists = false;
			if(result.rows[0]){
				exists = true;
			}
			callback(exists);
		}
	});

}
function compareHashPasswords(username, password, callback){
	var digestquery = "SELECT password from t_users where username like '" + username + "'";
	dbclient.query(digestquery, function(err, result){
		var dbpw = result.rows[0].password;
		//password = "\\x" + password;
		console.log(dbpw);
		console.log(password);
		if (password == dbpw){
			callback(true)
		}else{
			callback(false)
		}
	});
}
function checkPassword(username, password, callback){
	var createTMPtbl = "CREATE TABLE tmp_" + username + "(digest TEXT);"
	var insertTMPtbl = "INSERT into tmp_" + username + " SELECT digest('" + password + "', 'sha256') as pw;";
	var digestquerytmp = "SELECT digest from tmp_" + username + ";";
	dbclient.query(createTMPtbl, function(err, result){
		 if (err){
			logger.error("Couldnt create temp table." + err);
		}else{
			dbclient.query(insertTMPtbl, function(err, result){
				if (err){
					logger.err("Couldnt insert digest into temp table " + err);
				}else{
					dbclient.query(digestquerytmp, function(err, result){
						var newpwsha256 = result.rows[0].digest;
						//drop tmp table
						dbclient.query("DROP TABLE tmp_" + username);
						var digestquery = "SELECT password from t_users where username like '" + username + "'";
						dbclient.query(digestquery, function(err, result){
							var dbpw = result.rows[0].password; 
							if (newpwsha256 == dbpw){
								callback(true);
							}else{
								callback(false);
							}
						});
					});
				}
			});
		}
	});
}

function getUserInfo(user, callback){
	var query = "SELECT * FROM t_users where username like '" + user + "';";
	dbclient.query(query, function(err, result) {
		if (err){
			logger.error("getUserInfo: " + err);
		}else{
			var role = result.rows[0].role;
			var firstname = result.rows[0].firstname;
			var lastname = result.rows[0].lastname;
			var email = result.rows[0].email;
			var foto = result.rows[0].foto;
			var active = result.rows[0].active;
			callback(role, firstname, lastname, email, foto, active);
		}
		
	});
}
function getUserList(ok, callback){
	var query = "SELECT * FROM t_users"; 
	dbclient.query(query, function(err, result){
		if (err){
			logger.error("getUserList: " + err );
		}else{
			var counter = 1;
			result.rows.forEach(function (row) {
				var userdesc = "user" + counter;
				 	
				ok.userlist[userdesc] = { };
				ok.userlist[userdesc].username = row.username;
				ok.userlist[userdesc].role = row.role;
				ok.userlist[userdesc].firstname = row.firstname;
				ok.userlist[userdesc].lastname = row.lastname;
				ok.userlist[userdesc].email = row.email;
				ok.userlist[userdesc].foto = row.foto;
				ok.userlist[userdesc].active = row.active;
				counter++;
				logger.info(ok.userlist.user1.username); 
			});
				callback(ok);
			} 
		});
}

exports.createUser = function(JSONuser, callback){
	var response = {};
	response["requestType"] = "createUserResponse";
	userExists(JSONuser.username, function(userexist){
		if(userexist){
			response["message"] = "User " + JSONuser.username + " already exists.";
			callback(JSON.stringify(response));
		}else{
			var defs = "username, password, firstname, lastname, email, foto, active";
			//if (JSONuser == "undefined"){
			//}
			var values = 	"'" + JSONuser.username + "', " +
					"'" + JSONuser.password + "', " +
					"'" + JSONuser.firstname + "', " +
					"'" + JSONuser.lastname + "', " +
					"'" + JSONuser.email + "', " +
					"NULL, " +
					//"'" + JSONuser.foto + "', " +
					"'" + JSONuser.active + "'";
			var query_createuser = "INSERT INTO t_users(" + defs + ") VALUES(" + values + ")";
			dbclient.query(query_createuser, function(err, result){
				var qmsg;
				if (err){
					qmsg = "Couldnt create user " + JSONuser.username + " : " + err;
				}else{
					qmsg = "User " + JSONuser.username + " successfully created.";
				}
				logger.info(qmsg);
				response["message"] = qmsg;
				callback(JSON.stringify(response));
			});
		}
	});
}

exports.listUser = function(callback){
	var query_listusers = "SELECT username from t_users"; 
	var response = {};
	dbclient.query(query_listusers, function(err, result){
		if (err){
			response["message"] = "Could not get list of users";
			logger.error(errmsg);
			callback(errmsg);
		}else{
			var msg = "Successfully got list of all users.";
			response["requestType"] = "listUserResponse";
			var counter = 1;
			result.rows.forEach(function (row) {
				response["username" + counter] = row.username;
				counter++;
                        });
			var responseJSON = JSON.stringify(response);
			callback(responseJSON);
		}
	});
}

exports.addNewGPSData = function(JSONr, callback){
	var nok_obj = require('../messages/save_nok.json');
	var nok_str = JSON.stringify(nok_obj);
	var ok_obj = require('../messages/save_ok.json');
	var ok_str = JSON.stringify(ok_obj);
	var callback_str;
	 
	var defs = "latitude, longitude, username, groupname, date, time, street, city, state, county, country, plz, elevation, rowstatus, " +
		   "image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, "+
		   "image11, image12, image13, image14, image15, image16, image17, image18, image19, image20";
	var latitude = JSONr.latitude;
	var longitude = JSONr.longitude;
	var username = JSONr.username;
	//var groupname = 
	var date = JSONr.date;
	var time = JSONr.time;
	var rowstatus = JSONr.rowstatus;
	var street = JSONr.street;
	var city = JSONr.city;
	var state = JSONr.state;
	var county = JSONr.county;
	var country = JSONr.country;
	var plz = JSONr.plz;
	var elevation = JSONr.elevation;
	var image1 = JSONr.image1;
	var image2 = JSONr.image2;
	var image3 = JSONr.image3;
	var image4 = JSONr.image4;
	var image5 = JSONr.image5;
	var image6 = JSONr.image6;
	var image7 = JSONr.image7;
	var image8 = JSONr.image8;
	var image9 = JSONr.image9;
	var image10 = JSONr.image10;
	var image11 = JSONr.image11;
	var image12 = JSONr.image12;
	var image13 = JSONr.image13;
	var image14 = JSONr.image14;
	var image15 = JSONr.image15;
	var image16 = JSONr.image16;
	var image17 = JSONr.image17;
	var image18 = JSONr.image18;
	var image19 = JSONr.image19;
	var image20 = JSONr.image20;

	var groupname;
	//function 
	var uid;
	// check user
	async.series([
		function(callback){
			var uidquery = "select uid from t_users where username = '" + username  + "';";
			dbclient.query(uidquery, function(err,result){
				if (err){
					logger.error("addNewGPSData: select uid" + err );
				}else{
					result.rows.forEach(function (row) {
						//console.log("uid: " + row.uid);
						uid = row.uid;
						callback();
					});
				}
			});
		},
		function (callback){
			var gidquery = " select gid from t_users  JOIN t_groups on t_users.groupid = t_groups.gid where t_users.username = '" + username +"';";
			dbclient.query(gidquery, function(err, result){
				if (err){
					logger.error("addNewGPSData: select gid" + err );
				}else{
					result.rows.forEach(function (row) {
						//console.log("groupid: " + row.gid);
						groupid = row.gid;
					callback();
				});
			}
		});
		},
		function(callback){
			var values = "'" + latitude + "', '" + longitude + "', '" + uid + "', '" + groupid + "','" + date + "', '" + time + "', '" + street + "', '" + city + "', '" +
		     		     state + "', '" + county + "', '" + country + "', '" + plz + "', '" + elevation + "', '" + rowstatus  + "', '" + image1 + "', '" + image2 + "', '" +
		     		     image3 + "', '" + image4 + "', '" + image5 + "', '" + image6 + "', '" + image7 + "', '" + image8 + "', '" + image9 + "', '" + image10 + "', '" + image11  + "', '" +
		     		     image12 + "', '" + image13 + "', '" + image14 + "', '" + image15 + "', '" + image16 + "', '" + image17 + "', '" + image18 + "', '" + image19 + "', '" + image20 + "'";
			var query = "INSERT INTO t_gpsdata(" + defs + ") VALUES(" + values + ")";
			dbclient.query(query, function(err, result){
				if (err){
					logger.error("addNewGPSData - INSERT INTO t_gpsdata: " + err);
					callback(null, nok_str);
				}else{
					//callback to the optional callback 
					callback(null, ok_str); 
				}
			});
		}

			 
	],
	//optional callback
	// https://github.com/caolan/async#series
	function(err, results){
		//callback to app.js and passing the json string
		callback(results[2]);
	});
	
}

exports.GetUserData = function(username, callback){
	var groupid;
	var nok = require('../messages/userdata_nok.json');
	var nok_str = JSON.stringify(nok);
	var ok = require('../messages/userdata_ok.json');
	async.series([
                function (callback){
                        var gidquery = " select gid from t_users  JOIN t_groups  on t_users.groupid = t_groups.gid where t_users.username = '" + username +"';";
                        dbclient.query(gidquery, function(err, result){
                                if (err){
                                        logger.error("addNewGPSData: select gid" + err );
                                }else{
                                        result.rows.forEach(function (row) {
                                                //console.log("groupid: " + row.gid);
                                                groupid = row.gid;
                                                callback();
                                        });
                                }
                        });
                },
		function(callback){
			//var query = "select id,latitude,longitude,username,groupid,date,time,street,city,state,county,country,plz,elevation,rowstatus from t_gpsdata where groupid =" + groupid + ";";
			var query = "select id,latitude,longitude,t_users.username,t_gpsdata.groupid,date,time,street,city,state,county,country,plz,elevation,rowstatus from t_gpsdata JOIN t_users on t_gpsdata.username = t_users.uid where t_gpsdata.groupid =" + groupid + ";";

		 	dbclient.query(query, function(err, result){
                                if (err){
                                        logger.error("GetUserdata : SELECT from t_gpsdata: " + err);
                                        callback(null, nok_str);
                                }else{
                                        //callback to the optional callback
					//var counter = 1;
					
					ok.userdataresponse.results = result.rows;
					var jsonString = JSON.stringify(ok);
                                        callback(null, jsonString);
                                }
                        });
                }


        ],
        //optional callback
        // https://github.com/caolan/async#series
        function(err, results){
                //callback to app.js and passing the json string
		//console.log("-_- : " + results[1]);
                callback(results[1]);
        });

}
