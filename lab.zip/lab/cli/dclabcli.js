#!/app/node/bin/node


var fs = require('fs');
var program = require('commander');
var prompt = require('prompt');
var async = require('async');
var sha256 = require('sha256');
var colors = require('colors');
var request = require("request");
var https = require('https');

program
  .version('0.0.1')
  .option('-a, --action <action]','actiontype')
  .option('-u, --username [username]','username')
  .option('-e, --email [email]','email address')
  .option('-f, --firstname [firstname]','firstname required')
  .option('-l, --lastname [lastname]','lastname required')
  .option('-g, --groupname [groupname]','groupname')
  .option('-p, --picture [picture]','picture')
  .parse(process.argv);
  if (!process.argv.slice(2).length) {
    program.outputHelp(make_red);
  }


if (!program.action){
	console.log("try using -h or --help");
	process.exit(1)
}
//HTTP settings
var req;
var sslRootCAs = require('ssl-root-cas/latest')
sslRootCAs.inject()
sslRootCAs.addFile('../cert/server.crt');


var postdata;
if (program.action == 'createUser'){

	var mypassword;
	var user = require('../messages/c_userCreate.json');
	async.series([
		function(callback){
			var schema = {
                		properties: {
                        		password: {
                                		hidden: true
                        		}
                		}
        		};
        		prompt.start();
        		prompt.get(schema, function (err, result){
				mypassword = result.password;
				callback();
        		});
		},
		function(callback){
			user.password = sha256(mypassword);
			user.username = program.username;
			user.email = program.email;
			user.firstname = program.firstname;
			user.lastname = program.lastname;
			user.groupname = program.groupname;
			//user.foto = base64_encode(program.picture);
			user.active = true;
			postdata= JSON.stringify(user); 
			callback();
		},
		function(callback){
			sendRequest(postdata);
                        callback();
		}
	 ]);
}else if(program.action == 'listUser') {
	var userList = require('../messages/c_userList.json');
	postdata = JSON.stringify(userList);
	sendRequest(postdata);
}


function sendRequest(postdata){
 	var options= {
  	rejectUnauthorized: false,
  	host: "127.0.0.1",
  	port: 3000,
  	method: "POST",
  	headers: {
    		'Content-Type': 'application/json',
		'Content-Length': postdata.length
  		}
	};
	// request object
	req = https.request(options, function (res) {
 		var result = '';
  		res.on('data', function (chunk) {
    			result += chunk;
  		});
  		res.on('end', function () {
			var responseObject = JSON.parse(result);
			if (responseObject.requestType == "createUserResponse"){
    				console.log(responseObject.message);
			}else if (responseObject.requestType == "listUserResponse"){
				delete responseObject['requestType'];
				Object.keys(responseObject).forEach(function(key) {
					console.log(responseObject[key]);
				});
			}
  		});
  		res.on('error', function (err) {
    			console.log(err);
  		})
	});
	// req error
	req.on('error', function (err) {
		console.log("something went wrong bre");
  		process.exit(1);
	});

	req.write(postdata);
	req.end();
}

function make_red(txt) {
  return colors.red(txt);
}

//bin to Base64
function base64_encode(file) {
    var bitmap = fs.readFileSync(file);
    return new Buffer(bitmap).toString('base64');
}
