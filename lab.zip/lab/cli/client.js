#!/app/node/bin/node

var request = require("request");
var https = require('https');
// var fs = require("fs");
var postdataObj = require('../messages/c_userCreate.json');
var postdataString = JSON.stringify(postdataObj);

var commander = require('commander');

var sslRootCAs = require('ssl-root-cas/latest')
sslRootCAs.inject()
sslRootCAs.addFile('../crt/server.crt');
 
var options = {
  rejectUnauthorized: false,
  host: "127.0.0.1",
  port: 3000,
  method: "POST",
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Content-Length': postdataString.length
  }
};

// request object
var req = https.request(options, function (res) {
  var result = '';
  res.on('data', function (chunk) {
    result += chunk;
  });
  res.on('end', function () {
    console.log(result);
  });
  res.on('error', function (err) {
    console.log(err);
  })
});
 
// req error
req.on('error', function (err) {
  //console.log(err);
  process.exit(11);
});
 
//send request witht the postData form

req.write(postdataString);
req.end();
