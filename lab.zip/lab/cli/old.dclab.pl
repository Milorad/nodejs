#!/usr/bin/perl -w

use strict;
use Getopt::Long;

# Defaults
my ($action) = "undefined";
my ($username) = "undefined";
my ($email) = "undefined";
my ($firstname) = "undefined";
my ($lastname) = "undefined";
my ($group) = "undefined";


GetOptions(
    'action:s'		=> \$action,
    'username:s'	=> \$username,
    'email:s'		=> \$email,
    'firstname:s'	=> \$firstname,
    'lastname:s'	=> \$lastname,
    'group:s'		=> \$group,
    'help'		=> \&usage(),
) || usage();

print "test1\n";

sub usage {
	
	print STDERR <<EOF;
	Usage: $0
	-a	: action 		(default:$action)
		createUser
		updateUser
		listUsers
		showUser
		deleteUser
	-u	: username		(default:$username)
	-e	: email			(default:$username)
	-fn
EOF
	exit;
}

print "test\n";	

